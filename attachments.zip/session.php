<?php
if(isset($_POST['login']))
{
$username=$_POST['username'];
$password=$_POST['password'];
session_start();
$_SESSION['username']=$username;
header("location: edit_pro.php");
}
else
header("location: homepage1.php")
?>
