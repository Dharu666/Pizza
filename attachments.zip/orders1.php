
<!DOCTYPE html>
<html>
<head>
<title>Menu</title>
<style>
body{background-color:lavender;}
h1{text-align:center;}
button{text-align:right;}
table {border-collapse: collapse;}
td,th { padding:10px;border:2px solid black;}
<style>
div.container {
    width: 100%;
    border: 1px black;
}
header, footer {
    padding: 1em;
    color: white;
    background-color: DarkOrchid;
    clear: left;
    text-align: center;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: DarkOrchid;
}

li {
    float: right;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color:DarkOrchid;
}
ab 

.active {
    background-color:blue;
}
table, th, td {
    border: 1px solid black;
}
.btn {
    border: none;
    color: white;
    padding: 14px 28px;
    font-size: 16px;
    cursor: pointer;
}
.success {background-color: darkGreen;}
.success:hover {background-color: MediumSeaGreen;}
</style>

 </style>
<script type="text/javascript">
function mul1(n1,n2)
{
var no1=parseFloat(n1)
var no2=parseFloat(n2)
var no3=no1*no2
form1.total1.value=no3
}
function mul2(n1,n2)
{
var no1=parseFloat(n1)
var no2=parseFloat(n2)
var no3=no1*no2
form1.total2.value=no3
}
function mul3(n1,n2)
{
var no1=parseFloat(n1)
var no2=parseFloat(n2)
var no3=no1*no2
form1.total3.value=no3
}
function mul4(n1,n2)
{
var no1=parseFloat(n1)
var no2=parseFloat(n2)
var no3=no1*no2
form1.total4.value=no3
}
function mul5(n1,n2)
{
var no1=parseFloat(n1)
var no2=parseFloat(n2)
var no3=no1*no2
form1.total5.value=no3
}
function add(n1,n2,n3,n4,n5)
{
var no1=parseFloat(n1)
var no2=parseFloat(n2)
var no3=parseFloat(n3)
var no4=parseFloat(n4)
var no5=parseFloat(n5)
var no6=no1+no2+no3+no4+no5
form1.gtotal.value=no6
}
</script>
</head>
<body background="menu.jpg" >


<?php
session_start();
 $m=mysqli_connect("localhost","root","123456","sample") or die("ERROR");
 $q = "Select * from menu";
 $res =mysqli_query($m,$q) or die(mysqli_error());
 

?>

<center><h1><font color="white"><b>PIZZA</font></b></h1>
<right><a href="edit_pro.php"><button class="btn success">My account</button></a><br><br><br></right>

<table bgcolor="black",border="grey">
<h2>
<form action="pay.php" method="post" name="my_form">
<form>
<tr>
<td><b><font color="white">Select</font></td>
<td><b><center><font color="white">Item  Name </font></center></td>
<td><b><font color="white">Select the quantity</font></td>
<td><b><font color="white">Price</font></td>
<td><b><font color="white">Total</font></td>
<td><b></td>
</tr></h2>
<h3>

<?php
while($a=mysqli_fetch_array($res)){
$cost=$a['price'];
echo "<tr>";
echo "<td><center><input type=checkbox name=s></center></td>";
echo "<td><center><font color='white'>".$a['item_name']."</font></center></td>"; 
echo "<td><input type=number name=q1 required min=1 max=10 ></td>";
echo "<td><center><font color=white>".$a['price']."</font></center></td>";
echo "<td><input type=number name=total required min=1 max=10></td>";
echo "<td><input type=button name=total1 value=Total onclick=mul1(q1,$cost)></td>";
echo "</tr>";
}
?>
<br><br>
<center><a href="pay1.html"><button class="btn success">Pay</button></a></center>
</form>

</body>

</html>


