 <?php   
 session_start();  
 $connect = mysqli_connect('localhost', 'root', '123456', 'sample');  
 if(isset($_POST["add_to_cart"]))  
 {  
      if(isset($_SESSION["shopping_cart"]))  
      {  
           $item_array_id = array_column($_SESSION["shopping_cart"], "slno");  
           if(!in_array($_GET["id"], $item_array_id))  
           {  
                $count = count($_SESSION["shopping_cart"]);  
                $item_array = array(  
                     'slno'               =>     $_GET["id"],  
                     'item_name'               =>     $_POST["hidden_name"],  
                     'price'          =>     $_POST["hidden_price"],  
                     'quantity'          =>     $_POST["quantity"]  
                );  
                $_SESSION["shopping_cart"][$count] = $item_array;  
           }  
           else  
           {  
                echo '<script>alert("Item Already Added")</script>';  
                echo '<script>window.location="cart.php"</script>';  
           }  
      }  
      else  
      {  
           $item_array = array(  
                'slno'               =>     $_GET["id"],  
                'item_name'               =>     $_POST["hidden_name"],  
                'price'          =>     $_POST["hidden_price"],  
                'quantity'          =>     $_POST["quantity"]  
           );  
           $_SESSION["shopping_cart"][0] = $item_array;  
      }  
 }  
 if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "delete")  
      {  
           foreach($_SESSION["shopping_cart"] as $keys => $values)  
           {  
                if($values["slno"] == $_GET["id"])  
                {  
                     unset($_SESSION["shopping_cart"][$keys]);  
                     echo '<script>alert("Item Removed")</script>';  
                     echo '<script>window.location="cart.php"</script>';  
                }  
           }  
      }  
 } 
?>
 
<!DOCTYPE html>
<html>
<head>
<title>Online Pizza Delivery</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="orders.php">

<style>
div.container {
    width: 100%;
    border: 1px black;
}
header, footer {
    padding: 1em;
    color: white;
    background-color: indigo;
    clear: left;
    text-align: center;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: blue;
}

li {
    float: right;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color:indigo;
}
ab 

.active {
    background-color:blue;
}
</style>
      </head >  
      <body>  
           <br />  
           <div class="container" style="width:100%;">  
                <header><h1 align="center">Order Your Pizza</h1><br /></header>
<br/>

<ul>
<li><a href="homepage.php">Logout</a></li>
<li><a href="edit_pro.php">Profile</a></li>
<li><a href="about1.php">About</a></li>
  <li><a href="cart.php">Order</a></li>
  <li><a href="login.php">Home</a></li>

</ul>
  
                <?php  
                $query = "SELECT * FROM menu";  
                $result = mysqli_query($connect, $query);  
                if(mysqli_num_rows($result) > 0)  
                {  
                     while($row = mysqli_fetch_array($result))  
                     {  
                ?>  
                <div class="col-md-4" align="center">  
 

                     <form method="post" action="cart.php?action=add&id=<?php echo $row["slno"]; ?>">  
                          <div style="border:1px solid #333;  background-color:#ADD8E6; border-radius:5px; padding:16px;align="center">  
                                                             <center><h4 class="text-info"><?php echo $row["item_name"]; ?></h4></center>  
                               <center><h4 class="text-danger">Rs. <?php echo $row["price"]; ?></h4></center>  
                               <center><input type="text" name="quantity" class="form-control" value="1" /></center>  
                               <center><input type="hidden" name="hidden_name" value="<?php echo $row["item_name"]; ?>" /></center>  
                               <center><input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" /></center>  
                               <center><input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />  </center>
                          </div>  
                     </form>  


</table>
                </div>  
                <?php  
                     }  
                }  
                ?>  
                <div style="clear:both"></div>  
                <br />



                <h3 align="center"> <i>** Order Details **<i></h3>  
                <div class="table-responsive">  
                     <table border="3" width="1000" align="center" bgcolor="#7FFFD4",border="grey" class="table table-bordered">  
                          <tr>  
                               <center><th width="40%">Item Name</th>  
                               <th width="10%">Quantity</th>  
                               <th width="20%">Price</th>  
                               <th width="15%">Total</th>  
                               <th width="5%">Action</th></center>  
                          </tr>  
                          <?php   
                          if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
                          ?>  
                          <tr>  
                               <td><center><?php echo $values["item_name"]; ?></td></center>
                               <td><center><?php echo $values["quantity"]; ?></center></td>  
                               <td><center>Rs. <?php echo $values["price"]; ?></center></td>  
                               <td><center>Rs. <?php echo number_format($values["quantity"] * $values["price"], 2); ?></center></td>  
                               <td><center><a href="cart.php?action=delete&id=<?php echo $values["slno"]; ?>"><font color="black"><span class="text-danger">Remove</span></font></a></center></td>  
                          </tr>  
                          <?php  
                                    $total = $total + ($values["quantity"] * $values["price"]);  
                               }  
                          ?>  
                          <tr>  
                               <td colspan="3" align="right">Total</td>  
                               <td align="right">Rs. <?php echo number_format($total, 2); ?></td>  
                               <td></td>  
                          </tr>  
                          <?php  
                          }  
                          ?>  
                     </table>  
			<center><a href="pay1.html"><button class="btn success">Order</button></a></center>

<!--

			<table >  shopping
<?php
$dbc=mysqli_connect('localhost','root','123456','sample')or die('error connecting to mysql server');
$query="insert into orders values item_name='' and password='$form_password'";
$result=mysqli_query($dbc,$query)or die('error querying database');
$row=mysqli_fetch_array($result);
if($form_password==$row['password'])
{
echo "<h2><b>Order has been Updated in DB</b></h2>";
}
else
{
echo "<h2><b>Error In  DB...!!</b></h2>";
}
?>
                  
                          <?php   
                          if(!empty($_SESSION["shopping_cart"]))  
                          {  
                               $total = 0;  
                               foreach($_SESSION["shopping_cart"] as $keys => $values)  
                               {  
                          ?>  
                          <tr>  
                               <td><center><?php echo $values["item_name"]; ?></td></center>
                               <td><center><?php echo $values["quantity"]; ?></center></td>  
                               <td><center>Rs. <?php echo $values["price"]; ?></center></td>  
                               <td><center>Rs. <?php echo number_format($values["quantity"] * $values["price"], 2); ?></center></td>  
                               <td><center><a href="cart.php?action=delete&id=<?php echo $values["slno"]; ?>"><font color="black"><span class="text-danger">Remove</span></font></a></center></td>  
                          </tr>  
                          <?php  
                                    $total = $total + ($values["quantity"] * $values["price"]);  
                               }  
                          ?>  
                          <tr>  
                               <td colspan="3" align="right">Total</td>  
                               <td align="right">Rs. <?php echo number_format($total, 2); ?></td>  
                               <td></td>  
                          </tr>  
                          <?php  
                          }  
                          ?>  
                     </table>  

-->
                </div>  
           </div>  
           <br />  
      </body>  
 </html>
