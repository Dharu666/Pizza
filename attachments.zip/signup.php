<html>
<head>
<style>
body{background-color:plum;}</style>

<title>Sign-Up</title>
<style>
div.container {
    width: 100%;
    border: 1px black;
}
header, footer {
    padding: 1em;
    color: white;
    background-color: indigo;
    clear: left;
    text-align: center;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: paleVioletRed;
}

li {
    float: right;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color:indigo;
}
ab 

.active {
    background-color:blue;
}

</style>
</head>
<body>
<header><center><font size="30" color="white">Pizza</font></center></header><br>
<br/>
<ul>
<li><a href="homepage.html">Logout</a></li>
<li><a href="about.html">About</a></li>
  <li><a href="search.html">Search</a></li>
  <li><a href="signup.html">Sign-up</a></li>
<li><a href="homepage.html">Home</a></li>

</ul>
<br/>
<br/>
<h2><center>Hello!</center></h2>
<?php
$form_firstname=$_POST['firstname'];
$form_lastname=$_POST['lastname'];
$form_username=$_POST['username'];
$form_password=$_POST['password'];
$form_email=$_POST['email'];
$form_contactno=$_POST['contactno'];
$form_state=$_POST['state'];
$form_country=$_POST['country'];
echo "<br>";
$dbc=mysqli_connect('localhost','root','123456','sample')or die('Error Not able to connect to the database');
$sql1="insert into login(username,password) values('$form_username','$form_password')";
$sql2="insert into user_details(firstname,lastname,email,ph_no,username) values('$form_firstname','$form_lastname','$form_email',$form_contactno,'$form_username')";
$sql3="insert into location(state,country) values('$form_state','$form_country')";

if(mysqli_query($dbc,$sql1) &&mysqli_query($dbc,$sql2) &&mysqli_query($dbc,$sql3))
{
echo "<center>Your have successfully signed in!</center>";
echo "<br>";
}
else{
$count=mysqli_errno($dbc);
if(1062==$count)
{
echo "<center>Please try again with a different username!</center>";
}
else if(1064==$count && 0==$count)
{
echo"<center>There was a trouble with your sign up process. Please try again!</center>";
}
}


mysqli_close($dbc);
?>
</body>
</html>

