<html>
<head>
<title>Settings</title>
<style>
body{background-color:lavender;}
div.container {
    width: 100%;
    border: 1px black;
}
header, footer {
    padding: 1em;
    color: white;
    background-color: indigo;
    clear: left;
    text-align: center;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: paleVioletRed;
}

li {
    float: right;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color:indigo;
}
ab 

.active {
    background-color:blue;
}
.btn {
    border: none;
    color: white;
    padding: 14px 28px;
    font-size: 16px;
    cursor: pointer;
}
.success {background-color: indigo;}
.success:hover {background-color: plum;}

</style>
</head>
<body>
<header><center><font size="30" color="white">PIZZA</font></center></header><br>
<br/>
<ul>
<li><a href="homepage.php">Logout</a></li>
<li><a href="about1.php">About</a></li>
  <li><a href="cart.php">Order</a></li>
  <li><a href="signup.html">Sign-up</a></li>
<li><a href="login.html">Login</a></li>
<li><a href="homepage.php">Home</a></li>
</ul>
<br/>

<?php
session_start();
$form_username=$_SESSION['username'];
$form_password=$_POST['password'];
$form_cpassword=$_POST['cpassword'];
$form_email=$_POST['email'];
$form_phonenumber=$_POST['phoneno'];
$dbc=mysqli_connect('localhost','root','123456','sample')or die('Error Not able to connect to the database');
$sql="update login set password='$form_cpassword' where username='$form_username'";
$res=mysqli_query($dbc,$sql) or die('error querying database');

if($res){
echo "It has been updated successfully. Please make sure that you login with this updated Username henceforth! Thank You";
echo "<br>";}
else
echo "Problem updating your details. Please check your details and try again.";
mysqli_close($dbc);
?>
<br>
<center><a href="cart.php"><button class="btn success">Okay</button></a></center></center><br>
</body>
</html>
