<html>
<head>
<title>Image Page</title>
</head>
<body>
<?php
$db = mysqli_connect("localhost")
