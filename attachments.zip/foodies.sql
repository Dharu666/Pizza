-- MySQL dump 10.13  Distrib 5.7.20, for Linux (i686)
--
-- Host: localhost    Database: sample
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `location` (
  `loc_id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`loc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (1,'Winterfell','Rome'),(2,'Mystic Falls','USA'),(3,'Karnataka','India'),(4,'Goa','India');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES ('amulya','asdf'),('arya','1234'),('dragon','dragon'),('john','123'),('jon','12334'),('raghu','rsg'),('rohan','123');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `slno` int(3) NOT NULL,
  `item_name` varchar(20) DEFAULT NULL,
  `quantity` int(3) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `total` float DEFAULT NULL,
  PRIMARY KEY (`slno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'Gobi Manchurian',1,40,40),(2,'Veg Pakoda',1,25,25),(3,'Samosa',1,20,20),(4,'Meals',1,65,65),(5,'Masala Dosa',1,50,50);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_details`
--

DROP TABLE IF EXISTS `user_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_details` (
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `ph_no` bigint(15) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `loc_id` int(10) DEFAULT NULL,
  KEY `username` (`username`),
  KEY `loc_id` (`loc_id`),
  CONSTRAINT `user_details_ibfk_1` FOREIGN KEY (`username`) REFERENCES `login` (`username`),
  CONSTRAINT `user_details_ibfk_2` FOREIGN KEY (`loc_id`) REFERENCES `location` (`loc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_details`
--

LOCK TABLES `user_details` WRITE;
/*!40000 ALTER TABLE `user_details` DISABLE KEYS */;
INSERT INTO `user_details` VALUES ('Arya','Stark','aryastark@gmail.com',12345567,'arya',NULL),('Jon','Snow','jonsnow@gmail.com',12345567,'jon',NULL),('Raghu','Shankar','raghushankar.2008@gmail.com',9449871349,'raghu',NULL),('wd33','wd','john@gmail.com',123456789,'john',NULL),('Rohan','Rock','rohan@gmail.com',12345678,'rohan',NULL);
/*!40000 ALTER TABLE `user_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor_details`
--

DROP TABLE IF EXISTS `vendor_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor_details` (
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `email` varchar(15) DEFAULT NULL,
  `ph_no` bigint(20) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `loc_id` int(10) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  KEY `username` (`username`),
  KEY `loc_id` (`loc_id`),
  CONSTRAINT `vendor_details_ibfk_1` FOREIGN KEY (`username`) REFERENCES `vendor_login` (`username`),
  CONSTRAINT `vendor_details_ibfk_2` FOREIGN KEY (`loc_id`) REFERENCES `location` (`loc_id`),
  CONSTRAINT `vendor_details_ibfk_3` FOREIGN KEY (`loc_id`) REFERENCES `vendor_location` (`loc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor_details`
--

LOCK TABLES `vendor_details` WRITE;
/*!40000 ALTER TABLE `vendor_details` DISABLE KEYS */;
INSERT INTO `vendor_details` VALUES ('Jon','Snow','jjon@gmail.com',280193218,'jon',1,'NightsWatch'),('jksd','qsvbs','jjon@gmail.com',280193218,'john',NULL,'jksd'),('wdwef','wdwe','dmkdn@dnwje.com',1229380,'whitewalkers',NULL,'WDWEF'),('Katherine','Petrova','kat@gmail.com',1234567819,'kat',3,'FlorescentSellers'),('Elena','Gilbert','elena@gmail.com',1234567819,'elena',2,'TheRich'),('Arya','Stark','arry@gmail.com',1234568709,'arry',NULL,'Winterfell'),('Sansa','Stark','sansa@gmail.com',1234567890,'sansa',NULL,'Winterfell'),('Damon','Salvatore','damon@gmail.com',1234567899,'damon',NULL,'The Vamps');
/*!40000 ALTER TABLE `vendor_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor_location`
--

DROP TABLE IF EXISTS `vendor_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor_location` (
  `loc_id` int(10) NOT NULL AUTO_INCREMENT,
  `place` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `name` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`loc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor_location`
--

LOCK TABLES `vendor_location` WRITE;
/*!40000 ALTER TABLE `vendor_location` DISABLE KEYS */;
INSERT INTO `vendor_location` VALUES (1,'wkddnd','kdndn','jnj','NightsWatch'),(2,'Mystic Falls','Virginia','USA','TheRich'),(3,'Mystic Falls','Virginia','USA','FlorescentSellers'),(4,'MGRoad','Karnataka','Bangalore','Winterfell'),(5,'St.Louis','Longlence','Russia','The Vamps');
/*!40000 ALTER TABLE `vendor_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendor_login`
--

DROP TABLE IF EXISTS `vendor_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendor_login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendor_login`
--

LOCK TABLES `vendor_login` WRITE;
/*!40000 ALTER TABLE `vendor_login` DISABLE KEYS */;
INSERT INTO `vendor_login` VALUES ('',''),('amara','1234'),('arry','1234'),('damon','1234'),('elena','elena'),('john','123'),('jon','1234'),('kat','kat'),('raghu','rsg'),('sansa','1234'),('whitewalkers','123');
/*!40000 ALTER TABLE `vendor_login` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-12 20:59:06
