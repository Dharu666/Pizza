<!DOCTYPE html>
<html>
<head>
<title>Online Pizza Delivery</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="orders.php">

<style>
div.container {
    width: 100%;
    border: 1px black;
}
header, footer {
    padding: 1em;
    color: white;
    background-color: indigo;
    clear: left;
    text-align: center;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: blue;
}

li {
    float: right;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color:indigo;
}
ab 

.active {
    background-color:blue;
}
</style>
<title>Login</title>
</head>
<body background="fuit.jpeg">
<!--
<?php
session_start();
$_SESSION['username']=$_POST['username'];
?>
-->
<header>
   <h1>Pizza</h1>
</header>
<br/>
<ul>
<li><a href="logout.php">Logout</a></li>
<li><a href="about1.html">About</a></li>
  <li><a href="cart.php">Order</a></li>
<li><a href="edit_pro.php">Profile</a></li>
<li><a href="login.php">Home</a></li>

</ul>
<br/>
<br/>

<?php
$form_username=$_POST['username'];
$form_password=$_POST['password'];

echo "<br>";
$dbc=mysqli_connect('localhost','root','123456','sample')or die('error connecting to mysql server');
$query="select * from login where username='$form_username' and password='$form_password'";
$result=mysqli_query($dbc,$query)or die('error querying database');
$row=mysqli_fetch_array($result);
if($form_password==$row['password'])

		{

		echo "<br>";
		echo "<h3><b>Username:</h3>".$_SESSION['username'];
}
else
{
echo "<center>Not registered</center>";
echo "<br>";
echo "<br>";
echo '<center><a href="signup.html"><button>Signup</button></a></center>';
}
mysqli_close($dbc);
?>
</body>
</html>
