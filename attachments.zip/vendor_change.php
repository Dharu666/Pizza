<!DOCTYPE html>
<html>
<head><title>Profile</title>
<style>
body {
    background-color:lavender;
}

body {
    background-image:url(straw.jpg);
}
<style>
 #header-container 
 {
  background-color:blue;
   }.dropbtn {
    background-color: navy;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
}

.dropdown {
    position: relative;
    display: inline-block;
float: right;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: white}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: dodgerBlue;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
}

li {
    float: left;
}

li a {
    display: block;
    padding: 8px;
    background-color: #dddddd;
}
header, footer {
    padding: 1em;
    color: white;
    background-color: fireBrick;
    clear: left;
    text-align: center;
}
</style>
</head>
<head>
<div id="page">
		<div id="header-container">
			<div id="header">
			<img src="images.html.jpg"/>
</div>
</div>
<div class="dropdown">
  <button class="dropbtn">My account</button>
  <div class="dropdown-content" style="left:0;">
<ul>
<li><a href="search.html"><button>Search</button></a></li>
    <li><a href="cart.php"><button>Menu</button></a></li>
<li><a href="homepage.php"><button>Logout</button></a><li/>
  </ul>
  </div>
</div>
<header>
<center><b><font color="white" size="20">Online Pizza Delivery<h1></b></font></center>
</header>
<div id="content container">
<div id="content">
<ui:insert name="content"style="float:left;",position="fixed;">
<h3>
<?php
session_start();
$hi=$_SESSION['username'];
echo "<center><h2><font color=white><b>Username:</h2></center>";
echo "<center>$hi</center>";
echo "<br>";
?>
<form action="vendor_profile.php" method="post" name="my_form">

<center><font color="white"><label for="Password">Enter your original Password</label></center>
<center><font color="white"><input type="password" name="password" ></font></br></center>
<center><font color="white"><label for="Password">Enter the Password you want to change</label></center>
<center><font color="white"><input type="password" name="cpassword" ></font></br></center>

<center><font color="white"><label for="Email">Email</label></center>
<center><font color="white"><input type="email" name="email" ></font></br></center>
<center><font color="white"><label for="Phone number">Phone number</label></center>
<center><font color="white"><input type="text" name="phoneno" ></font></br></center>
<text area rows="10"column="10"></text area>
<center><a href="vendor_profile.php"><button>Edit Profile</button></a></center></center><br>
</h3>
</form>
</ui:insert>
</div>
</div>


</body>
</html>
