<!DOCTYPE html>
<html>
<head>
<title>Online Pizza Delivery</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="orders.php">

<style>
div.container {
    width: 100%;
    border: 1px black;
}
header, footer {
    padding: 1em;
    color: white;
    background-color: indigo;
    clear: left;
    text-align: center;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: blue;
}

li {
    float: right;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color:indigo;
}
ab 

.active {
    background-color:blue;
}
</style>
</head>
<title>LogIn</title>
<body bgcolor="lavender">

<div class="main">

<header>
   <h1>Online Pizza Delivery</h1>
</header>
<br/>
<ul>
<li><a href="about.html">About</a></li>
  <li><a href="search.html">Search</a></li>
  <li><a href="ord1.php">Order</a></li>
  <li><a href="signup.html">Sign-up</a></li>
<li><a href="login.html">Login</a></li>
<li><a href="homepage.php">Home</a></li>

</ul>
<br />



<?php
$place=$_POST['place1'];
echo "<p>Results found for: <i> $place</i></p>";
$dbc=mysqli_connect('localhost','root','123456','sample')or die('Error Not able to connect to the database');
$sql="select * from vendor_location where place='$place'";
$sql2="select loc_id from vendor_location where place='$place'";
$res=mysqli_query($dbc,$sql) or die('error querying database');
$res2=mysqli_query($dbc,$sql2) or die('error querying database');
 ?>
<center><h2>
<table bgcolor="pink",border="black">
<tr>
<th><b>Name </b></th>
<th><b>Place </b></th>
<th><b>State </b></th>
<th><b>Country</b></th>
</tr></h2><h3>
<?php while($r=mysqli_fetch_array($res)) {
echo "<tr>";
echo "<td><center>" .$r['name']. "</center></td>";
echo "<td><center>" .$r['place']. "</center></td>";
echo "<td><center>" .$r['state']."</center></td>";
echo "<td><center>" .$r['country']."</center></td>";
echo "</tr></br>";
}
mysqli_close($dbc);
?>
</h3></table>  </center>
<br>

</body>
</html>
