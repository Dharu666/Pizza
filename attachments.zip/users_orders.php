<html>
<head>
<style>
body{background-color:lightpink;}</style>
<title>Bill Information</title>
</head>
<body>
<?php
$form_price=$_POST['item'];
$form_qty=$_POST['qty'];

echo "<center>Bill details</center>";
echo "<br>";
$form_price=$form_price*$form_qty;
echo "Your bill";
echo $form_price;
?>

<center><a href="users_orders.html"><button>Back</button></a></center>
<center><a href="pay.html"><button>Confirm</button></a></center>
</body>
</html>
