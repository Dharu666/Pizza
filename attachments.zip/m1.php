
<!DOCTYPE html>
<html>
<head>
<title>Menu</title>
<style>
body{background-color:lavender;}
h1{text-align:center;}
button{text-align:right;}
table {border-collapse: collapse;}
td,th { padding:10px;border:2px solid black;}
<style>
div.container {
    width: 100%;
    border: 1px black;
}
header, footer {
    padding: 1em;
    color: white;
    background-color: DarkOrchid;
    clear: left;
    text-align: center;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: DarkOrchid;
}

li {
    float: right;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color:DarkOrchid;
}
ab 

.active {
    background-color:blue;
}
.btn {
    border: none;
    color: white;
    padding: 14px 28px;
    font-size: 16px;
    cursor: pointer;
}
.success {background-color: darkGreen;}
.success:hover {background-color: MediumSeaGreen;}


</style>

 </style>
</head>
<body>

<?php
 $m=mysqli_connect("localhost","root","123456","sample") or die("ERROR");
 $q = "Select * from menu";
 $res =mysqli_query($m,$q);
 
?>

<center><table >
<tr>
<th>Items : </th>
<th>Item Name</th>
<th>Quantity</th>
<th>Price of each item</th>
</tr>
<?php while($r=mysqli_fetch_array($res)) {
 echo"<tr>";
echo "<td>" .$r['slno']. "</td>";
echo "<td>" .$r['item_name']."</td>";
echo "<td>" .$r['quantity']."</td>";
echo "<td>" .$r['price']."</td>";
echo "</tr>";
}
?>
</table>  </center>



</body>
</html>
