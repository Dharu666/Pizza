<!DOCTYPE html>
<html>
<head>
<title>Online Pizza Delivery</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="orders.php">

<style>
div.container {
    width: 100%;
    border: 1px black;
}
header, footer {
    padding: 1em;
    color: white;
    background-color: indigo;
    clear: left;
    text-align: center;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: blue;
}

li {
    float: right;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color:indigo;
}
ab 

.active {
    background-color:blue;
}
</style>
</head>
<title>LogIn</title>
<body bgcolor="lavender">

<div class="main">

<header>
   <h1>Online Pizza Delivery</h1>
</header>
<br/>
<ul>
<li><a href="about.html">About</a></li>
  <li><a href="search.html">Search</a></li>
  <li><a href="ord1.php">Order</a></li>
  <li><a href="signup.html">Sign-up</a></li>
<li><a href="login.html">Login</a></li>
<li><a href="homepage.php">Home</a></li>

</ul>
<br />

<div align="center">
<h2>You have to <u>login</u> first before you Order your Pizza</h2>
<p><a href="login.html">Login</p>
</div>


</html>

