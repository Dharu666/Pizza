<html>
<head>
<style>
body{background-color:lavender;}
.btn {
    border: none;
    color: white;
    padding: 14px 28px;
    font-size: 16px;
    cursor: pointer;
}
header, footer {
    padding: 1em;
    color: white;
    background-color: black;
    clear: left;
    text-align: center;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: DimGrey;
}

li {
    float: right;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color:Black;
}


</style>
<title>Login</title>
</head>
<?php
session_start();
$_SESSION['username']=$_POST['username'];
?>

<header><center><font size="30" color="white">Online Pizza Delivery</font></center></header><br>
<body background="temp2.jpg">
<ul>
<li><a href="logout.php">Logout</a></li>
  <li><a href="see_orders.php">Orders</a></li>
<li><a href="vendor_change.php">Profile</a></li>
<li><a href="vendor_login.php">Home</a></li>

</ul>
<br/>

<?php
$form_username=$_SESSION['username'];
$form_password=$_POST['password'];

echo "<h1><center>Welcome</font></center></h1>";
echo "<br>";
$dbc=mysqli_connect('localhost','root','123456','sample')or die('error connecting to mysql server');
$query="select * from vendor_login where username='$form_username' and password='$form_password'";
$result=mysqli_query($dbc,$query)or die('error querying database');
$row=mysqli_fetch_array($result);
if($form_password==$row['password'])
		{echo "<h2><b>You have successfully logged in!</b></h2>";
		echo "<br>";
		echo "Username:".$_SESSION['username'];
}
else
{
echo "<center>Not registered</center>";
echo "<br>";
echo "<br>";
echo '<center><a href="signup.html"><button>Signup</button></a></center>';
}
mysqli_close($dbc);
?>
</body>
</html>
