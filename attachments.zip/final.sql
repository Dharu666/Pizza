-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 15, 2018 at 02:33 PM
-- Server version: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.28-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sample`
--

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `loc_id` int(11) NOT NULL,
  `state` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`loc_id`, `state`, `country`) VALUES
(1, 'Winterfell', 'Rome'),
(2, 'Mystic Falls', 'USA'),
(3, 'Karnataka', 'India'),
(4, 'Goa', 'India'),
(5, 'Karnataka', 'India'),
(6, 'Karnataka', 'India'),
(7, 'bsvc', 'scscs');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('AK666', '666666'),
('amulya', 'asdf'),
('arya', '6666'),
('dffd', 'sds'),
('dragon', 'dragon'),
('john', ''),
('jon', '12334'),
('mki', '159'),
('raghu', 'rsg'),
('rohan', '123');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `slno` int(3) NOT NULL,
  `item_name` varchar(20) DEFAULT NULL,
  `quantity` int(3) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `total` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`slno`, `item_name`, `quantity`, `price`, `total`) VALUES
(1, 'Normal Pizza', 1, 100, 100),
(2, 'Tandoori Panner', 1, 250, 250),
(3, 'Triple Chicken Feast', 1, 450, 450),
(4, 'Veggi Supreeme', 1, 250, 250),
(5, 'Chicken Sausage', 1, 280, 280),
(6, 'Margherita', 1, 270, 270);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `item_name` varchar(20) NOT NULL,
  `quality` int(3) NOT NULL,
  `price` float NOT NULL,
  `total` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `ph_no` bigint(15) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `loc_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`firstname`, `lastname`, `email`, `ph_no`, `username`, `loc_id`) VALUES
('Arya', 'Stark', 'aryastark@gmail.com', 12345567, 'arya', NULL),
('Jon', 'Snow', 'jonsnow@gmail.com', 12345567, 'jon', NULL),
('Raghu', 'Shankar', 'raghushankar.2008@gmail.com', 9449871349, 'raghu', NULL),
('wd33', 'wd', 'john@gmail.com', 123456789, 'john', NULL),
('Rohan', 'Rock', 'rohan@gmail.com', 12345678, 'rohan', NULL),
('Dhareppa', 'S', 'dharu@gmail.com', 7353379990, 'AK666', NULL),
('rocky', 'mlp', 'sds@gmail.com', 7896523412, 'mki', NULL),
('fdffd', 'fddfdfd', 'dhareppa6sfsf66@gmail.com', 7896523415, 'dffd', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vendor_details`
--

CREATE TABLE `vendor_details` (
  `firstname` varchar(20) DEFAULT NULL,
  `lastname` varchar(20) DEFAULT NULL,
  `email` varchar(15) DEFAULT NULL,
  `ph_no` bigint(20) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `loc_id` int(10) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor_details`
--

INSERT INTO `vendor_details` (`firstname`, `lastname`, `email`, `ph_no`, `username`, `loc_id`, `name`) VALUES
('Jon', 'Snow', 'jjon@gmail.com', 280193218, 'jon', 1, 'NightsWatch'),
('jksd', 'qsvbs', 'jjon@gmail.com', 280193218, 'john', NULL, 'jksd'),
('wdwef', 'wdwe', 'dmkdn@dnwje.com', 1229380, 'whitewalkers', NULL, 'WDWEF'),
('Katherine', 'Petrova', 'kat@gmail.com', 1234567819, 'kat', 3, 'FlorescentSellers'),
('Elena', 'Gilbert', 'elena@gmail.com', 1234567819, 'elena', 2, 'TheRich'),
('Arya', 'Stark', 'arry@gmail.com', 1234568709, 'arry', NULL, 'Winterfell'),
('Sansa', 'Stark', 'sansa@gmail.com', 1234567890, 'sansa', NULL, 'Winterfell'),
('Damon', 'Salvatore', 'damon@gmail.com', 1234567899, 'damon', NULL, 'The Vamps'),
('Dhareppa', 'Sasalatti', 'ak@gmail.com', 7353379990, 'Dharu', NULL, 'AK pizza delivery');

-- --------------------------------------------------------

--
-- Table structure for table `vendor_location`
--

CREATE TABLE `vendor_location` (
  `loc_id` int(10) NOT NULL,
  `place` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `name` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor_location`
--

INSERT INTO `vendor_location` (`loc_id`, `place`, `state`, `country`, `name`) VALUES
(1, 'wkddnd', 'kdndn', 'jnj', 'NightsWatch'),
(2, 'Mystic Falls', 'Virginia', 'USA', 'TheRich'),
(3, 'Mystic Falls', 'Virginia', 'USA', 'FlorescentSellers'),
(4, 'MGRoad', 'Karnataka', 'Bangalore', 'Winterfell'),
(5, 'St.Louis', 'Longlence', 'Russia', 'The Vamps'),
(6, 'Bangalore', 'Karnataka', 'India', 'AK pizza delivery');

-- --------------------------------------------------------

--
-- Table structure for table `vendor_login`
--

CREATE TABLE `vendor_login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor_login`
--

INSERT INTO `vendor_login` (`username`, `password`) VALUES
('amara', '1234'),
('arry', '1234'),
('damon', '1234'),
('Dharu', 'qwert'),
('elena', ''),
('john', '123'),
('jon', '1234'),
('kat', 'kat'),
('raghu', 'rsg'),
('sansa', '1234'),
('whitewalkers', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`loc_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`slno`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD KEY `username` (`username`),
  ADD KEY `loc_id` (`loc_id`);

--
-- Indexes for table `vendor_details`
--
ALTER TABLE `vendor_details`
  ADD KEY `username` (`username`),
  ADD KEY `loc_id` (`loc_id`);

--
-- Indexes for table `vendor_location`
--
ALTER TABLE `vendor_location`
  ADD PRIMARY KEY (`loc_id`);

--
-- Indexes for table `vendor_login`
--
ALTER TABLE `vendor_login`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `loc_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `vendor_location`
--
ALTER TABLE `vendor_location`
  MODIFY `loc_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_details`
--
ALTER TABLE `user_details`
  ADD CONSTRAINT `user_details_ibfk_1` FOREIGN KEY (`username`) REFERENCES `login` (`username`),
  ADD CONSTRAINT `user_details_ibfk_2` FOREIGN KEY (`loc_id`) REFERENCES `location` (`loc_id`);

--
-- Constraints for table `vendor_details`
--
ALTER TABLE `vendor_details`
  ADD CONSTRAINT `vendor_details_ibfk_1` FOREIGN KEY (`username`) REFERENCES `vendor_login` (`username`),
  ADD CONSTRAINT `vendor_details_ibfk_2` FOREIGN KEY (`loc_id`) REFERENCES `location` (`loc_id`),
  ADD CONSTRAINT `vendor_details_ibfk_3` FOREIGN KEY (`loc_id`) REFERENCES `vendor_location` (`loc_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
